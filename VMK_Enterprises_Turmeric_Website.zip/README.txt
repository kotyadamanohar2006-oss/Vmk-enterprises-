VMK ENTERPRISES WEBSITE

Updated with a Products section:
1. Turmeric Finger - Polished - ₹180
2. Turmeric Finger - Unpolished - ₹165

The two supplied turmeric photos are included in the website, plus a combined turmeric banner.

How to run on iQOO Z9x:
1. Extract the ZIP.
2. Open index.html in Chrome.
3. The website works offline except WhatsApp and Google Maps links.

To edit products:
Open index.html in a mobile code editor and change the product names, prices or descriptions.
